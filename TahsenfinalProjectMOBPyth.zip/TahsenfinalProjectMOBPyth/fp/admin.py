from django.contrib import admin
from .models import user, usercontact

admin.site.register(user)
admin.site.register(usercontact)