from django import forms
from matplotlib.widgets import Widget

class signupForm(forms.Form):
    fname = forms.CharField(max_length=50, label='First Name')
    lname = forms.CharField(max_length=50, label='Last Name')
    email = forms.CharField(max_length=100, label='Email', widget=forms.EmailInput)
    password = forms.CharField(max_length=100, label='New Password', widget=forms.PasswordInput)

class loginForm(forms.Form):
    email = forms.CharField(max_length=50, label='username', widget=forms.TextInput(attrs={ 'placeholder' : '@email'}))
    password = forms.CharField(max_length=100, label='password', widget=forms.PasswordInput(attrs={ 'placeholder' : 'Password'}))

class contactForm(forms.Form):
    name = forms.CharField(max_length=100, label = 'Full name')
    email = forms.CharField(max_length=100, label = 'Your email', widget=forms.EmailInput)
    subject = forms.CharField(max_length=100, label='Subject')
    message = forms.CharField(widget=forms.Textarea(attrs={"rows":5,"cols":20}))
