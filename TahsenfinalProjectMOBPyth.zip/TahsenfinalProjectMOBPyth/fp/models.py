from django.db import models

# Create your models here.
class user(models.Model):
    dbfname = models.CharField(max_length=50)
    dblname = models.CharField(max_length=50)
    dbemail = models.CharField(max_length=100)
    dbpass = models.CharField(max_length=100)
    def __str__(self):
        return self.dbfname + " " + self.dblname + " " + self.dbemail

class usercontact(models.Model):
    dbfullName = models.CharField(max_length=100)
    dbemail = models.CharField(max_length=100)
    dbsubject = models.CharField(max_length=100)
    dbmessage = models.CharField(max_length=1000)
    
    def __str__(self):
        return self.dbfullName + " " + self.dbsubject


