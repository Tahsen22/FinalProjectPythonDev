from distutils.log import error
from sre_constants import SUCCESS
from django.shortcuts import redirect, render
from .forms import signupForm, loginForm, contactForm
from.models import user, usercontact
from django.core import serializers
import json



def index(request):
    return render(request, 'pages/index.html')

def shop(request):
    return render(request, 'pages/shop.html')

def about(request):
    return render(request, 'pages/about.html')

def contact(request):
    if request.method == 'POST':
        contactFormData = contactForm(request.POST)
        if contactFormData.is_valid():
            fullName = contactFormData.cleaned_data['name']
            email = contactFormData.cleaned_data['email']
            subject = contactFormData.cleaned_data['subject']
            message = contactFormData.cleaned_data['message']

            message = usercontact(dbfullName = fullName, dbemail = email, dbsubject = subject, dbmessage = message)
            message.save()
            
            form = contactForm ()
            success = "Message sent!"
            return render(request, 'pages/contact.html', {'form': form, 'note': success})
    else:
        form = contactForm()
        return render(request, 'pages/contact.html', {'form' : form})

def profile(request):
    if request.session.has_key('email'):
        return render(request, 'pages/profile.html', { 'Name' : request.session['fname'] + " " + request.session['lname'], 'email': request.session['email'] })
    else:
        request.session['error'] = "You need to log in first to go to profile!"
        return redirect('login')

def signup(request):
    if request.method == 'POST':
        submitted_form = signupForm(request.POST)
        if submitted_form.is_valid():
            firstName = submitted_form.cleaned_data['fname']
            lastName = submitted_form.cleaned_data['lname']
            userEmail = submitted_form.cleaned_data['email']
            userPassword = submitted_form.cleaned_data['password']

            if user.objects.filter(dbemail = userEmail):
                note = "Account alredy exists!"
                form = signupForm()
                return render(request, 'pages/signup.html', {'signupForm': form, 'note':note})
            
            else:
                user_data = user(dbfname = firstName, dblname = lastName, dbemail = userEmail, dbpass = userPassword)
                user_data.save()

            request.session['fname'] = firstName
            request.session['lname'] = lastName
            request.session['email'] = userEmail

            return redirect('/profile')

    else:
        form = signupForm()
        return render(request, 'pages/signup.html', {'signupForm' : form})



def login(request):
    if request.method == 'POST':
        submitted_form = loginForm(request.POST)
        if submitted_form.is_valid():
            userEmail = submitted_form.cleaned_data['email']
            userPassword = submitted_form.cleaned_data['password']
            member = user.objects.filter(dbemail = userEmail, dbpass = userPassword)
            if member:
                member = serializers.serialize('json', member)
                userinfo = json.loads(member)
                request.session['fname'] = userinfo[0]['fields']['dbfname']
                request.session['lname'] = userinfo[0]['fields']['dblname']
                request.session['email'] = userinfo[0]['fields']['dbemail']

                return redirect('profile')
            else:
                loginError = "Email or Passeord is wrong!"
                form = loginForm()
                return render(request, 'pages/login.html', {'loginForm' : form, 'Error': loginError})
    else:
        if request.session.has_key('error'):
            error = request.session['error']
        else:
            error = ""
        form = loginForm()
        return render(request, 'pages/login.html', {'loginForm' : form, 'Error': error})




def sproduct(request):
    return render(request, 'pages/sproduct.html')

def cart(request):
    return render(request, 'pages/cart.html')

def logout(request):
    del request.session['fname']
    del request.session['lname']    
    del request.session['email']
    if request.session.has_key('error'):
        del request.session['error']
    return redirect('/login')
